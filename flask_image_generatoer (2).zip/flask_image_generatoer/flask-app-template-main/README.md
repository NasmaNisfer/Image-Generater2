# flask-app-template
Starting template for a python Flask application

Check out out [YouTube Channel here](https://www.youtube.com/c/SkoloOnline)
